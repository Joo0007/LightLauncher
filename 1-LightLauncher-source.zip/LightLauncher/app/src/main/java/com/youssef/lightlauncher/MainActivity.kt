package com.youssef.lightlauncher

import android.app.AlertDialog
import android.app.ApplicationInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.app.Activity
import kotlin.math.abs

private data class LaunchableApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE) }
    private val apps = mutableListOf<LaunchableApp>()
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var title: TextView
    private lateinit var grid: GridLayout
    private lateinit var scroll: ScrollView
    private lateinit var hint: TextView
    private var drawerMode = false
    private var currentQuery = ""
    private var foreground = Color.rgb(30, 32, 40)
    private var bgColor = Color.rgb(245, 246, 250)
    private var surface = Color.WHITE
    private var accent = Color.rgb(83, 109, 254)
    private var startX = 0f
    private var startY = 0f
    private var gestureHandled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyColors()
        loadApps()
        buildUi()
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                gestureHandled = false
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - startX
                val dy = event.y - startY
                val threshold = ViewConfiguration.get(this).scaledTouchSlop * 5
                val atTop = !::scroll.isInitialized || scroll.scrollY == 0
                if (!gestureHandled && abs(dy) > threshold && abs(dy) > abs(dx)) {
                    if (dy < 0 && !drawerMode) setMode(true)
                    else if (dy > 0 && drawerMode && atTop) setMode(false)
                    gestureHandled = true
                }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onResume() {
        super.onResume()
        if (::grid.isInitialized) {
            loadApps()
            renderApps()
        }
    }

    private fun applyColors() {
        val theme = prefs.getString("theme", "system") ?: "system"
        val dark = when (theme) {
            "dark" -> true
            "light" -> false
            else -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
        }
        foreground = if (dark) Color.rgb(240, 241, 246) else Color.rgb(30, 32, 40)
        bgColor = if (dark) Color.rgb(18, 19, 24) else Color.rgb(245, 246, 250)
        surface = if (dark) Color.rgb(34, 36, 44) else Color.WHITE
        accent = if (dark) Color.rgb(165, 180, 252) else Color.rgb(83, 109, 254)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
        window.decorView.systemUiVisibility = if (!dark) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results: List<ResolveInfo> = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        apps.clear()
        results.mapNotNull { info ->
            val activity = info.activityInfo ?: return@mapNotNull null
            val packageName = activity.packageName
            val label = info.loadLabel(packageManager)?.toString()?.trim().orEmpty().ifBlank { packageName }
            val icon = try { info.loadIcon(packageManager) } catch (_: Exception) { packageManager.defaultActivityIcon }
            LaunchableApp(label, packageName, icon)
        }.distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .forEach(apps::add)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
            setBackgroundColor(bgColor)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        title = TextView(this).apply {
            text = if (drawerMode) "All apps" else "Home"
            textSize = 25f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(foreground)
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        val settingsButton = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setTextColor(accent)
            background = rounded(surface, 24)
            minWidth = dp(48)
            setOnClickListener { showSettings() }
        }
        header.addView(title)
        header.addView(settingsButton)
        root.addView(header)

        search = EditText(this).apply {
            hint = "Search apps"
            textSize = 16f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(foreground)
            setHintTextColor(if (isDark()) Color.LTGRAY else Color.GRAY)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(surface, 16)
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10); bottomMargin = dp(12) }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    currentQuery = s?.toString().orEmpty()
                    renderApps()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        root.addView(search)

        hint = TextView(this).apply {
            textSize = 13f
            setTextColor(if (isDark()) Color.LTGRAY else Color.DKGRAY)
            setPadding(dp(2), 0, dp(2), dp(8))
        }
        root.addView(hint)
        scroll = ScrollView(this).apply { isFillViewport = true }
        grid = GridLayout(this).apply {
            columnCount = prefs.getInt("columns", 4)
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        scroll.addView(grid)
        val body = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            addView(scroll, FrameLayout.LayoutParams(-1, -1))
        }
        root.addView(body)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, dp(58))
        }
        nav.addView(navButton("Home") { setMode(false) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("All apps") { setMode(true) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("Settings") { showSettings() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(nav)
        setContentView(root)
        renderApps()
    }

    private fun navButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(accent)
        background = rounded(bgColor, 16)
        setOnClickListener { action() }
    }

    private fun setMode(drawer: Boolean) {
        drawerMode = drawer
        title.text = if (drawer) "All apps" else "Home"
        renderApps()
    }

    private fun renderApps() {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val favorites = prefs.getStringSet("favorites", emptySet()).orEmpty()
        val base = if (drawerMode) apps else if (favorites.isEmpty()) apps.take(12) else apps.filter { it.packageName in favorites }
        val query = currentQuery.trim()
        val shown = if (query.isEmpty()) base else apps.filter { it.label.contains(query, true) || it.packageName.contains(query, true) }
        grid.columnCount = prefs.getInt("columns", 4).coerceIn(3, 6)
        hint.text = when {
            !drawerMode && favorites.isEmpty() && query.isEmpty() -> "Swipe up or tap All apps. Long-press an app to pin it here."
            drawerMode -> "Swipe down for Home. Long-press an app for options."
            else -> "Long-press an app to change your Home screen."
        }
        if (shown.isEmpty()) {
            val empty = TextView(this).apply {
                text = if (apps.isEmpty()) "No launchable apps found." else "No apps found."
                textSize = 16f
                setTextColor(foreground)
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(32), dp(24), dp(32))
            }
            grid.addView(empty, GridLayout.LayoutParams().apply { width = resources.displayMetrics.widthPixels - dp(36); height = dp(100) })
            return
        }
        shown.forEach { app ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(8))
                isClickable = true
                isFocusable = true
                setOnClickListener { launch(app) }
                setOnLongClickListener { showAppOptions(app); true }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(7) }
            }
            val label = TextView(this).apply {
                text = app.label
                textSize = 12f
                setTextColor(foreground)
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            tile.addView(icon)
            tile.addView(label)
            val width = (resources.displayMetrics.widthPixels - dp(36)) / grid.columnCount
            grid.addView(tile, GridLayout.LayoutParams().apply {
                this.width = width
                height = dp(98)
                setMargins(dp(1), dp(2), dp(1), dp(2))
            })
        }
    }

    private fun launch(app: LaunchableApp) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(intent) } catch (_: Exception) { showAppOptions(app) }
        }
    }

    private fun showAppOptions(app: LaunchableApp) {
        val favs = prefs.getStringSet("favorites", emptySet()).orEmpty().toMutableSet()
        val isFavorite = app.packageName in favs
        val choices = arrayOf(if (isFavorite) "Remove from Home" else "Add to Home", "App info")
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(choices) { _, which ->
                if (which == 0) {
                    if (isFavorite) favs.remove(app.packageName) else favs.add(app.packageName)
                    prefs.edit().putStringSet("favorites", favs).apply()
                    renderApps()
                } else {
                    try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))) } catch (_: Exception) { }
                }
            }
            .show()
    }

    private fun showSettings() {
        val options = arrayOf("Theme: System", "Theme: Light", "Theme: Dark", "Grid: 3 columns", "Grid: 4 columns", "Grid: 5 columns", "Grid: 6 columns", "Choose default Home app")
        AlertDialog.Builder(this)
            .setTitle("Launcher settings")
            .setItems(options) { _, index ->
                when (index) {
                    0, 1, 2 -> {
                        val value = listOf("system", "light", "dark")[index]
                        prefs.edit().putString("theme", value).apply()
                        applyColors()
                        buildUi()
                    }
                    in 3..6 -> {
                        prefs.edit().putInt("columns", index).apply()
                        renderApps()
                    }
                    7 -> try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                }
            }
            .show()
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun isDark() = bgColor == Color.rgb(18, 19, 24)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
